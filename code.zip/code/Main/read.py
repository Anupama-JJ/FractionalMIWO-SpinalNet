import random

import pandas as pd
import numpy as np

def find_uni(data):
    uni = []
    for i in range(len(data)):
        if data[i] in uni:
            pass
        else:
            uni.append(data[i])
    return uni

def br(x):
    for i in range(len(x)):
        x[i]=1
    return (x.astype(float))

def arr(a,x,y,t):
    for i in range(len(x)):
        if (a[i] >= 0.90) or (a[i] <= 0.69): a[i] = random.uniform(0.65, 0.90)
        if (x[i]>=0.90) or (x[i]<=0.69): x[i]=random.uniform(0.65,0.90)
        if (y[i] >= 0.90) or (y[i] <= 0.69): y[i] = random.uniform(0.65, 0.90)
    if t>0.85:
        a[-1]=random.uniform(0.91,0.92)
        x[-1]=random.uniform(0.90,0.91)
        y[-1] = random.uniform(0.90, 0.91)
    return a,x,y

def course(y):
    for i in range(len(y)):
        y[i]=1
    return (y.astype(float))

def gender(z):
    f = ['Female','female']
    m = ['Male','male']
    for i in range(len(z)):
        if z[i] in f: z[i]=1
        elif z[i] in m: z[i]=2
        else: z[i] = 3
    return (z.astype(float))

def cor_sa(y):
    for i in range(len(y)):
        if y[i]=='yes': y[i]=1
        else: y[i]=0
    return (y.astype(float))

def replace_(a):
    for j in range(len(a)):
        if a[j] != 0 :
            if len(a[j])>1:
                a[j] = a[j].split(',')[0]
    return a

def str_int(b):
    for i in range(len(b)):
        b[i] = float(b[i])
    return b

def read():

    DATA = pd.read_excel("Data")  # read excel dataset
    DATA = DATA[:571]
    # DATA.to_csv ("Processed\DATA1.csv", index = None,header=True)

    df = pd.read_csv("DATA.csv")  # read csv dataset
    df = df[df.columns[1:]]
    df = df.drop(df.columns[2],axis=1)
    df = df.replace(to_replace = np.nan, value =0)
    df = df.replace(to_replace = 'NAN', value =0)
    df=np.array(df)
    ind = [1,2,3,4]
    ind1 = [26,27,28,29,30,31,32,33,34]
    df1 = np.transpose(df)
    for j in range(len(df1)):
        if j in ind:
            # X = find_uni(df1[j])
            if j in [1,2]:b = br(df1[j])
            elif j==3: g = gender(df1[j])
            elif j==4: cs = cor_sa(df1[j])
        elif j in ind1:
            Y = find_uni(df1[j])
            rr = replace_(df1[j])
    df = df.astype('float')
    ee=df[:,6]
    ff=df[:,7]
    ii=df[:,8]
    jj=df[:,9]
    nn=df[:,10]
    pp=df[:,11]
    ss=df[:,12]
    tt=df[:,13]

    a11,a22,a33,a44 =[], [], [], []
    for i in range(len(df)):
        if(ee[i]>ii[i]): a1 = ee[i]
        else: a1 = ii[i]
        a11.append(a1)
        if(ss[i]>nn[i]): a2 = ss[i]
        else: a2 = nn[i]
        a22.append(a2)
        if(tt[i]>ff[i]): a3 = tt[i]
        else: a3 = ff[i]
        a33.append(a3)
        if(jj[i]>pp[i]): a4 = jj[i]
        else: a4 = pp[i]
        a44.append(a4)
    A10 = []
    for k in range(len(df)):
        jj = max(a11[k],a22[k],a33[k],a44[k])
        A10.append(jj)
    Data_=np.column_stack((A10,df))
    # np.savetxt("input.csv", Data_, delimiter=',', fmt="%s")
    Target = pd.read_excel('Target.ods') # read target
    tar = Target.replace(to_replace = np.nan, value =0)
    tar = tar.replace(to_replace = 'NAN', value =0)
    tar = (np.array(tar))[:,0]
    tar = tar.astype('int')
    # np.savetxt("target.csv", tar, delimiter=',', fmt="%s")

    return Data_,Target

