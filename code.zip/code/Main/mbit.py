import random
import pandas as pd
import numpy as np
data = pd.read_csv("DATA.csv")
data1 = np.array(data)
s1 = data1[:,2]
dept =[561,5,5]  #CS, EC, MECH
e = data1[:,8]
f = data1[:,9]
i = data1[:,10]
j = data1[:,11]
n = data1[:,12]
p = data1[:,13]
s = data1[:,14]
t = data1[:,15]
a11,a22,a33,a44,A=[],[],[],[],[]
for k in range(len(data1)):
    if (e[k] > f[k]):
        a1 = e[k] / dept[k]
    else:a1 = f[k] / dept[k]
    a11.append(a1)

    if (i[k] > j[k]):
        a2 = i[k] / dept[k]
    else:a2 = j[k] / dept[k]
    a22.append(a2)

    if (n[k] > p[k]):
       a3 =  n[k] / dept[k]
    else:a3 = p[k] / dept[k]
    a33.append(a3)

    if (s[k] > t[k]):
        a4 = s[k] / dept[k]
    else:a4 = t[k] / dept[k]
    a44.append(a4)

MBIT = np.column_stack((s1,a11,a22,a33,a44))
# np.savetxt("Processed//mbit1.csv", MBIT, delimiter=',', fmt="%s")

