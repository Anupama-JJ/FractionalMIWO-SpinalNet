import pandas as pd
import numpy as np
import random,math
import scipy.stats as stats

def transformation(Data1,Target1):
    DT = stats.zscore(Data1)
    DT = np.nan_to_num(DT)
    return DT