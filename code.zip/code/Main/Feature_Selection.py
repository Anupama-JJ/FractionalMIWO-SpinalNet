from turtle import pd
import pandas as pd
from Main import sfcm
import pickle
import numpy as np
import os

def feature_selection(X):
    N_c = 18
    F1 = sfcm.SFCM(n_clusters=N_c)
    X = np.array(X).transpose()
    # X[np.isnan(X)]=0
    # X[np.isinf(X)] = 255
    F1.fit(X)
    ss = sum(sum(F1.u))
    ss1 = int(np.round(ss))
    X_new = X[0:ss1,:]
    X_new = np.transpose(X_new)

    return X_new

