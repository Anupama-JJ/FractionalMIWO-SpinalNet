from Main import Feature_Selection, read, Data_Transformation
import Proposed_p2.SpinalNet, Proposed_p2.SpinalNet2
import pandas as pd
import numpy as np

tr=90
Pr,Re,F = [],[],[]
data,target=read.read() # read input
tran=Data_Transformation.transformation(data,target) # Data transformation
feat=Feature_Selection.feature_selection(tran) # feature selection

######################Proposed#######################
Proposed_p2.SpinalNet.sn(feat,target,tr,Pr,Re,F)


