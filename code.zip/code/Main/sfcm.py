import numpy as np
from scipy.linalg import norm
from scipy.spatial.distance import cdist
import random

class SFCM:
    def __init__(self, n_clusters=10, max_iter=100, m=2, error=1e-5, random_state=42):
        self.u, self.centers = None, None
        self.n_clusters = n_clusters
        self.max_iter = max_iter
        self.m = m
        self.error = error
        self.random_state = random_state

    def fit(self, X):
        # a=random.randint(100,960)
        # a=358
        # if a>X.shape[0]:
        # X=X[0:a,:]
        N = X.shape[0]
        C = self.n_clusters
        centers = []

        # u = np.random.dirichlet(np.ones(C), size=N)
        r = np.random.RandomState(self.random_state)
        u = r.rand(N,C)
        u = u / np.tile(u.sum(axis=1)[np.newaxis].T,C)
        # u=u[:,0,3]
        # u = np.isnan(u).any()
        # u = np.isinf(u).any()

        iteration = 0
        while iteration < self.max_iter:
            u2 = u.copy()
            centers = self.next_centers(X, u)
            centers[np.isnan(centers)] = 0
            u = self.next_u(X, centers)
            u = u[:, 0:C]
            u=np.nan_to_num(u)
            iteration += 1

            # Stopping rule
            if norm(u-u2) < self.error:
                break

        self.u = u
        self.centers = centers
        return self

    def next_centers(self, X, u):
        u=0
        um=[]
        X = np.asarray(X, dtype='float64')
        for i in range (len(X)):
            a=(u ** self.m)
            um.append(a)
        um = np.asarray(um, dtype='float64')
        return (X.T @ um / np.sum(um, axis=0)).T

    def next_u(self, X, centers):
        return self._predict(X, centers)

    def _predict(self, X, centers):
        # a=356
        # centers=np.nan_to_num(centers)
        centers = np.zeros((len(X), len(X[0])))
        power = float(2 / (self.m - 1))
        # if X.shape[0]>a:
        #     X=X[0:a,:]
        #     centers=centers[0:a,:]
        temp = cdist(X, centers) ** power
        denominator_ = temp.reshape((X.shape[0], 1, -1)).repeat(temp.shape[-1], axis=1)
        denominator_ = temp[:, :, np.newaxis] / denominator_

        return 1 / denominator_.sum(2)

    def predict(self, X):
        if len(X.shape) == 1:
            X = np.expand_dims(X, axis=0)

        u = self._predict(X, self.centers)
        return np.argmax(u, axis=-1)
