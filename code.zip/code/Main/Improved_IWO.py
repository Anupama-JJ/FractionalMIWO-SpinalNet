import numpy as np, random

def Algm():
    N = 5           # Number of Decision Variables
    M = 4 # Decision Variables Matrix Size
    VarMin = -10       #Lower Bound of Decision Variables
    VarMax = 10        #Upper Bound of Decision Variables
    Position = 0

    Tmax = 2    #Maximum Number of Iterations
    nPop0 = 10     #Initial Population Size
    nPop = 5      #Maximum Population Size
    Smin = 0       #Minimum Number of Seeds
    Smax = 5       #Maximum Number of Seeds
    Exponent = 2           #Variance Reduction Exponent
    sigma_initial = 0.5    #Initial Value of Standard Deviation
    sigma_final = 0.001	#Final Value of Standard Deviation

    def Fitness(soln):  # creating function for fitness
        S = []
        for i in range(len(soln)):
            s = 0
            for j in range(len(soln[i])):
                s += soln[i][j] * random.random()
            f = 1 / s
            S.append(f)
        return S
    def solution(N, M):  # generating solution
        data = []
        for i in range(N):  # N rows, M columns
            tem = []
            for j in range(M): tem.append(random.random())  # random values
            data.append(tem)
        return data

    pos = solution(N,M)
    Costs = Fitness(pos)
    BestCost = np.min(Costs)
    WorstCost = np.max(Costs)

    best_soln = np.zeros([4, 1], dtype=float)     #initializing the best soln as zero 4X1 matrix
    nXL = np.argmin(Costs)
    best_fit = np.min(Costs)
    best_soln = pos[nXL]
    t=0
    while t<Tmax:
        # Update Standard Deviation
        sigma = ((Tmax - t) / (Tmax - 1)) ** Exponent * (sigma_initial - sigma_final) + sigma_final
        # Get Best and Worst Cost Values
        Costs = Fitness(pos)
        BestCost = min(Costs)
        WorstCost = max(Costs)
        # Initialize Offsprings Population
        newpop = []
        # Reproduction
        for i in range(len(pos)):
            ratio = (np.array(Costs[i]) - WorstCost) / (BestCost - WorstCost)
            S = np.round(int(Smin + (Smax - Smin) * ratio))
            new_S = []
            for j in range(S):
                newsol = (((random.uniform(0,1)* (np.array(pos[i]))* nXL* (sigma-1) - best_soln))/sigma).tolist() ###update equation
                new_S.append(newsol)
                cost = Fitness(new_S)
                newpop=newpop+new_S
        pos = pos+newpop
        new_fit = Fitness(pos)  # fitness calculation
        NF = np.argmin(new_fit)
        nXL = np.argmin(Costs)
        if (np.min(new_fit) < best_fit):  # comparing maximum of new_fit and fit
            XL = pos[NF]  # assigning XL value as the row value of NF
            best_fit = np.min(new_fit)

        Costs = new_fit.copy()

        #print(['At iteration ' + str(t) + ' the best fitness is ' + str(best_fit)])

        t = t + 1

    return np.max(best_soln)










